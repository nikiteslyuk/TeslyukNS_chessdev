"""Initialization file."""

from .__main__ import *
